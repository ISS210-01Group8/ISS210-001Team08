# ISS210FinalTemplate
This is a template for the ISS210's final webstie on social justice (not required for students to use).
You should use this file to drop citations for all the images, articles, etc. that you use. 
Be sure to replace the following with your substitions.
ISSFront: https://www.every.org/racial-justice
SJImage1: https://www.pinterest.ca/pin/408772103654309571/
SJImage2: Youtube
SJImage3: https://bloody-disgusting.com/editorials/3601617/evolution-undead-brief-history-zombies-horror/
SJImage4: https://stock.adobe.com/search?k=economic+justice 
SJImage5: https://www.jamesgmartin.center/2018/08/social-justice-is-overrunning-the-university-of-texas/
SJImage6: https://www.facebook.com/groups/1016906918423966/ 
Zombies in Revolt: The Violent Revolution of American Cinematic Monsters; DOI: 10.15291/sic/2.4.lc.2 
